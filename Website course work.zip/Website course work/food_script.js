function onimage()
{
    document.getElementById("img1").src ='peking duck.jpg'
}


function offimage()
{
    document.getElementById("img1").src ='china flag.png'
}

function onimage_2()
{
    document.getElementById("img2").src ='Taco.png'
}


function offimage_2()
{
    document.getElementById("img2").src ='mex flag.jpg'
}

function onimage_3()
{
    document.getElementById("img3").src ='Sushi.jpg'
}


function offimage_3()
{
    document.getElementById("img3").src ='jap flag.jpg'
}

function onimage_4()
{
    document.getElementById("img4").src ='rice.png'
}


function offimage_4()
{
    document.getElementById("img4").src ='india flag.svg'
}

function onimage_5()
{
    document.getElementById("img5").src ='pasta.png'
}


function offimage_5()
{
    document.getElementById("img5").src ='italy flag.webp'
}

function onimage_6()
{
    document.getElementById("img6").src ='dutch dish.jpg'
}


function offimage_6()
{
    document.getElementById("img6").src ='dutch flag.png'
}